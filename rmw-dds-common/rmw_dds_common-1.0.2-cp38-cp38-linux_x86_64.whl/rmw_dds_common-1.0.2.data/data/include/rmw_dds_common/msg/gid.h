// generated from rosidl_generator_c/resource/idl.h.em
// with input from rmw_dds_common:msg/Gid.idl
// generated code does not contain a copyright notice

#ifndef RMW_DDS_COMMON__MSG__GID_H_
#define RMW_DDS_COMMON__MSG__GID_H_

#include "rmw_dds_common/msg/detail/gid__struct.h"
#include "rmw_dds_common/msg/detail/gid__functions.h"
#include "rmw_dds_common/msg/detail/gid__type_support.h"

#endif  // RMW_DDS_COMMON__MSG__GID_H_
