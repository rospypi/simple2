// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_srvs:srv/Trigger.idl
// generated code does not contain a copyright notice

#ifndef STD_SRVS__SRV__TRIGGER_H_
#define STD_SRVS__SRV__TRIGGER_H_

#include "std_srvs/srv/detail/trigger__struct.h"
#include "std_srvs/srv/detail/trigger__functions.h"
#include "std_srvs/srv/detail/trigger__type_support.h"

#endif  // STD_SRVS__SRV__TRIGGER_H_
