// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/MultiArrayLayout.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__MULTI_ARRAY_LAYOUT_H_
#define STD_MSGS__MSG__MULTI_ARRAY_LAYOUT_H_

#include "std_msgs/msg/detail/multi_array_layout__struct.h"
#include "std_msgs/msg/detail/multi_array_layout__functions.h"
#include "std_msgs/msg/detail/multi_array_layout__type_support.h"

#endif  // STD_MSGS__MSG__MULTI_ARRAY_LAYOUT_H_
