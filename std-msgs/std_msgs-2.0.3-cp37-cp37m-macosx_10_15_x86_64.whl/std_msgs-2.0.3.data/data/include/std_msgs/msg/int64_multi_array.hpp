// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__INT64_MULTI_ARRAY_HPP_
#define STD_MSGS__MSG__INT64_MULTI_ARRAY_HPP_

#include "std_msgs/msg/detail/int64_multi_array__struct.hpp"
#include "std_msgs/msg/detail/int64_multi_array__builder.hpp"
#include "std_msgs/msg/detail/int64_multi_array__traits.hpp"

#endif  // STD_MSGS__MSG__INT64_MULTI_ARRAY_HPP_
