# tinyxml_vendor
Vendor package for providing tinyxml within a cmake package
