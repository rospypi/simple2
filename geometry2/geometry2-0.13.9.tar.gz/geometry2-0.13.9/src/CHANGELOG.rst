^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package geometry2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.13.9 (2020-12-09)
-------------------

0.13.8 (2020-12-08)
-------------------

0.13.7 (2020-11-18)
-------------------

0.13.6 (2020-10-28)
-------------------
* Update maintainers of the ros2/geometry2 fork. (`#328 <https://github.com/ros2/geometry2/issues/328>`_) (`#332 <https://github.com/ros2/geometry2/issues/332>`_)
* Contributors: Alejandro Hernández Cordero

0.13.5 (2020-08-05)
-------------------

0.13.4 (2020-06-03)
-------------------

0.13.3 (2020-05-26)
-------------------

0.13.2 (2020-05-18)
-------------------

0.13.1 (2020-05-08)
-------------------

0.13.0 (2020-04-30)
-------------------
* Uncommented tf2_bullet and tf2_tools (`#260 <https://github.com/ros2/geometry2/issues/260>`_)
* Contributors: Alejandro Hernández Cordero

0.12.4 (2019-11-19)
-------------------

0.12.3 (2019-11-18)
-------------------

0.12.2 (2019-11-18)
-------------------

0.12.1 (2019-10-23)
-------------------
* Port geometry2 metapackage to ROS 2 to be able to use it in variants (`#184 <https://github.com/ros2/geometry2/issues/184>`_)
* Contributors: Mikael Arguedas

0.5.15 (2017-01-24)
-------------------

0.5.14 (2017-01-16)
-------------------
* create geometry2 metapackage and make geometry_experimental depend on it for clarity of reverse dependency walking.
* Contributors: Tully Foote
