// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_HPP_
#define DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_HPP_

#include "diagnostic_msgs/msg/detail/diagnostic_array__struct.hpp"
#include "diagnostic_msgs/msg/detail/diagnostic_array__builder.hpp"
#include "diagnostic_msgs/msg/detail/diagnostic_array__traits.hpp"

#endif  // DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_HPP_
