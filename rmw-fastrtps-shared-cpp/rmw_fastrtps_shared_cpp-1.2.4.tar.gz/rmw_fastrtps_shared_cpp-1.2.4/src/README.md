# `rmw_fastrtps_shared_cpp`

`rmw_fastrtps_shared_cpp` provides common code for static and dynamic type support of rmw_fastrtps_cpp.

## Quality Declaration

This package claims to be in the **Quality Level 2** category, see the [Quality Declaration](QUALITY_DECLARATION.md) for more details.
