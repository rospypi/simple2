// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STATISTICS_MSGS__MSG__METRICS_MESSAGE_HPP_
#define STATISTICS_MSGS__MSG__METRICS_MESSAGE_HPP_

#include "statistics_msgs/msg/detail/metrics_message__struct.hpp"
#include "statistics_msgs/msg/detail/metrics_message__builder.hpp"
#include "statistics_msgs/msg/detail/metrics_message__traits.hpp"

#endif  // STATISTICS_MSGS__MSG__METRICS_MESSAGE_HPP_
