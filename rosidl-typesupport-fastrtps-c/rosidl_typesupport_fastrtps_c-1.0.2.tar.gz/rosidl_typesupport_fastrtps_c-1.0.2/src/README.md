# rosidl_typesupport_fastrtps_c

`rosidl_typesupport_fastrtps_c` is a package that provides functionality for generating rosidl C interfaces for eProsima FastRTPS.

## Features

`rosidl_typesupport_fastrtps_c` features are described in [FEATURES](docs/FEATURES.md).

## Quality Declaration

This package claims to be in the **Quality Level 2** category, see the [Quality Declaration](QUALITY_DECLARATION.md) for more details.
