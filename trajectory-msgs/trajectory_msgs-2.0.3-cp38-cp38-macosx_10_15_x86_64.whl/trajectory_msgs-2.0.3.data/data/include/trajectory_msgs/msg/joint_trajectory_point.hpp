// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_POINT_HPP_
#define TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_POINT_HPP_

#include "trajectory_msgs/msg/detail/joint_trajectory_point__struct.hpp"
#include "trajectory_msgs/msg/detail/joint_trajectory_point__builder.hpp"
#include "trajectory_msgs/msg/detail/joint_trajectory_point__traits.hpp"

#endif  // TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_POINT_HPP_
