// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__MSG__TRANSITION_DESCRIPTION_HPP_
#define LIFECYCLE_MSGS__MSG__TRANSITION_DESCRIPTION_HPP_

#include "lifecycle_msgs/msg/detail/transition_description__struct.hpp"
#include "lifecycle_msgs/msg/detail/transition_description__builder.hpp"
#include "lifecycle_msgs/msg/detail/transition_description__traits.hpp"

#endif  // LIFECYCLE_MSGS__MSG__TRANSITION_DESCRIPTION_HPP_
