// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_HPP_
#define LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_HPP_

#include "lifecycle_msgs/msg/detail/transition_event__struct.hpp"
#include "lifecycle_msgs/msg/detail/transition_event__builder.hpp"
#include "lifecycle_msgs/msg/detail/transition_event__traits.hpp"

#endif  // LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_HPP_
