// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__NAV_SAT_STATUS_HPP_
#define SENSOR_MSGS__MSG__NAV_SAT_STATUS_HPP_

#include "sensor_msgs/msg/detail/nav_sat_status__struct.hpp"
#include "sensor_msgs/msg/detail/nav_sat_status__builder.hpp"
#include "sensor_msgs/msg/detail/nav_sat_status__traits.hpp"

#endif  // SENSOR_MSGS__MSG__NAV_SAT_STATUS_HPP_
