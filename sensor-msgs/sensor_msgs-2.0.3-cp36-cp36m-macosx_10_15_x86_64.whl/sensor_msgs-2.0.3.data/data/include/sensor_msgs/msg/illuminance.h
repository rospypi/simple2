// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/Illuminance.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__ILLUMINANCE_H_
#define SENSOR_MSGS__MSG__ILLUMINANCE_H_

#include "sensor_msgs/msg/detail/illuminance__struct.h"
#include "sensor_msgs/msg/detail/illuminance__functions.h"
#include "sensor_msgs/msg/detail/illuminance__type_support.h"

#endif  // SENSOR_MSGS__MSG__ILLUMINANCE_H_
