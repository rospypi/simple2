// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__BATTERY_STATE_HPP_
#define SENSOR_MSGS__MSG__BATTERY_STATE_HPP_

#include "sensor_msgs/msg/detail/battery_state__struct.hpp"
#include "sensor_msgs/msg/detail/battery_state__builder.hpp"
#include "sensor_msgs/msg/detail/battery_state__traits.hpp"

#endif  // SENSOR_MSGS__MSG__BATTERY_STATE_HPP_
