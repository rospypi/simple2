// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/JoyFeedbackArray.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__JOY_FEEDBACK_ARRAY_H_
#define SENSOR_MSGS__MSG__JOY_FEEDBACK_ARRAY_H_

#include "sensor_msgs/msg/detail/joy_feedback_array__struct.h"
#include "sensor_msgs/msg/detail/joy_feedback_array__functions.h"
#include "sensor_msgs/msg/detail/joy_feedback_array__type_support.h"

#endif  // SENSOR_MSGS__MSG__JOY_FEEDBACK_ARRAY_H_
