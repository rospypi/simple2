// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/MagneticField.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__MAGNETIC_FIELD_H_
#define SENSOR_MSGS__MSG__MAGNETIC_FIELD_H_

#include "sensor_msgs/msg/detail/magnetic_field__struct.h"
#include "sensor_msgs/msg/detail/magnetic_field__functions.h"
#include "sensor_msgs/msg/detail/magnetic_field__type_support.h"

#endif  // SENSOR_MSGS__MSG__MAGNETIC_FIELD_H_
