^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package eigen3_cmake_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2019-08-08)
------------------
* Handle Eigen3 3.3.4 chocolatey package (`#3 <https://github.com/ros2/eigen3_cmake_module/issues/3>`_)
* Update README (`#2 <https://github.com/ros2/eigen3_cmake_module/issues/2>`_)
* Contributors: Marya Belanger, Shane Loretz

0.1.0 (2019-08-06)
------------------

* Initial release (`#1 <https://github.com/ros2/eigen3_cmake_module/pull/1>`_)
* Contributors: Shane Loretz

