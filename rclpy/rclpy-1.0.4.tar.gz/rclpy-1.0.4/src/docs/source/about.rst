About
=====

The canonical Python API for `ROS 2 <https://index.ros.org/doc/ros2>`_.

*rclpy* is built on the common C-API provided by `rcl <https://github.com/ros2/rcl>`_.

