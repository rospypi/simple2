Initialization, Shutdown, and Spinning
======================================

.. automodule:: rclpy
