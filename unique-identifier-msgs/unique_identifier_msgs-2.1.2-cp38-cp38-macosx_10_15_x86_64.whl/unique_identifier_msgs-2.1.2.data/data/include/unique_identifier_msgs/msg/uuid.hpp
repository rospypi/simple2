// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UNIQUE_IDENTIFIER_MSGS__MSG__UUID_HPP_
#define UNIQUE_IDENTIFIER_MSGS__MSG__UUID_HPP_

#include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"
#include "unique_identifier_msgs/msg/detail/uuid__builder.hpp"
#include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"

#endif  // UNIQUE_IDENTIFIER_MSGS__MSG__UUID_HPP_
