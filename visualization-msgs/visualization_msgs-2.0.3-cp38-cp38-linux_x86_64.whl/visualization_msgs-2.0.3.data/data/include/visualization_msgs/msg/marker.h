// generated from rosidl_generator_c/resource/idl.h.em
// with input from visualization_msgs:msg/Marker.idl
// generated code does not contain a copyright notice

#ifndef VISUALIZATION_MSGS__MSG__MARKER_H_
#define VISUALIZATION_MSGS__MSG__MARKER_H_

#include "visualization_msgs/msg/detail/marker__struct.h"
#include "visualization_msgs/msg/detail/marker__functions.h"
#include "visualization_msgs/msg/detail/marker__type_support.h"

#endif  // VISUALIZATION_MSGS__MSG__MARKER_H_
