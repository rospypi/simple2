// generated from rosidl_generator_c/resource/idl.h.em
// with input from visualization_msgs:srv/GetInteractiveMarkers.idl
// generated code does not contain a copyright notice

#ifndef VISUALIZATION_MSGS__SRV__GET_INTERACTIVE_MARKERS_H_
#define VISUALIZATION_MSGS__SRV__GET_INTERACTIVE_MARKERS_H_

#include "visualization_msgs/srv/detail/get_interactive_markers__struct.h"
#include "visualization_msgs/srv/detail/get_interactive_markers__functions.h"
#include "visualization_msgs/srv/detail/get_interactive_markers__type_support.h"

#endif  // VISUALIZATION_MSGS__SRV__GET_INTERACTIVE_MARKERS_H_
