// generated from rosidl_generator_c/resource/idl.h.em
// with input from visualization_msgs:msg/InteractiveMarkerPose.idl
// generated code does not contain a copyright notice

#ifndef VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_POSE_H_
#define VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_POSE_H_

#include "visualization_msgs/msg/detail/interactive_marker_pose__struct.h"
#include "visualization_msgs/msg/detail/interactive_marker_pose__functions.h"
#include "visualization_msgs/msg/detail/interactive_marker_pose__type_support.h"

#endif  // VISUALIZATION_MSGS__MSG__INTERACTIVE_MARKER_POSE_H_
