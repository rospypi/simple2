// generated from rosidl_generator_c/resource/idl.h.em
// with input from move_base_msgs:action/MoveBase.idl
// generated code does not contain a copyright notice

#ifndef MOVE_BASE_MSGS__ACTION__MOVE_BASE_H_
#define MOVE_BASE_MSGS__ACTION__MOVE_BASE_H_

#include "move_base_msgs/action/detail/move_base__struct.h"
#include "move_base_msgs/action/detail/move_base__functions.h"
#include "move_base_msgs/action/detail/move_base__type_support.h"

#endif  // MOVE_BASE_MSGS__ACTION__MOVE_BASE_H_
