^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package move_base_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.2 (2019-09-30)
------------------
* port move_base_msgs to ROS2 actions (`#10 <https://github.com/ros-planning/navigation_msgs/issues/10>`_)
* Contributors: Steven Macenski

2.0.0 (2018-06-27)
------------------
* Contributors: William Woodall

1.13.0 (2015-03-16)
-------------------
* initial release from new repository
* Contributors: Michael Ferguson
