// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MOVE_BASE_MSGS__ACTION__MOVE_BASE_HPP_
#define MOVE_BASE_MSGS__ACTION__MOVE_BASE_HPP_

#include "move_base_msgs/action/detail/move_base__struct.hpp"
#include "move_base_msgs/action/detail/move_base__builder.hpp"
#include "move_base_msgs/action/detail/move_base__traits.hpp"

#endif  // MOVE_BASE_MSGS__ACTION__MOVE_BASE_HPP_
