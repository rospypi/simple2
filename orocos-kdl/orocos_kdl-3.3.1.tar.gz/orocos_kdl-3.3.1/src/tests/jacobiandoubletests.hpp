#ifndef PVDOUBLETESTS_H
#define PVDOUBLETESTS_H



#include <kdl/jacobianexpr.hpp>
#include <kdl/jacobiandouble.hpp>
#include "jacobiantests.hpp"


namespace KDL {

void checkDoubleOps();

}
#endif




