// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTION_MSGS__SRV__CANCEL_GOAL_HPP_
#define ACTION_MSGS__SRV__CANCEL_GOAL_HPP_

#include "action_msgs/srv/detail/cancel_goal__struct.hpp"
#include "action_msgs/srv/detail/cancel_goal__builder.hpp"
#include "action_msgs/srv/detail/cancel_goal__traits.hpp"

#endif  // ACTION_MSGS__SRV__CANCEL_GOAL_HPP_
