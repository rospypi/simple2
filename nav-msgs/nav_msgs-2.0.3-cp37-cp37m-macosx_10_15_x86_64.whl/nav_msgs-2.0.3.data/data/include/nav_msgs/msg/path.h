// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav_msgs:msg/Path.idl
// generated code does not contain a copyright notice

#ifndef NAV_MSGS__MSG__PATH_H_
#define NAV_MSGS__MSG__PATH_H_

#include "nav_msgs/msg/detail/path__struct.h"
#include "nav_msgs/msg/detail/path__functions.h"
#include "nav_msgs/msg/detail/path__type_support.h"

#endif  // NAV_MSGS__MSG__PATH_H_
