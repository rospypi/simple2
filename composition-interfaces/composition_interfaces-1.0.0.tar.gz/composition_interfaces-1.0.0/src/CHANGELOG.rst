^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package composition_interfaces
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2020-05-26)
------------------
* Add quality declarations for each package except test_msgs (`#92 <https://github.com/ros2/rcl_interfaces/issues/92>`_)
* Contributors: brawner

0.9.0 (2020-04-25)
------------------

0.8.0 (2019-09-26)
------------------

0.7.4 (2019-05-29)
------------------

0.7.3 (2019-05-20)
------------------

0.7.2 (2019-05-08)
------------------

0.7.1 (2019-04-26)
------------------

0.7.0 (2019-04-14)
------------------
* Correct minor typo (`#65 <https://github.com/ros2/rcl_interfaces/issues/65>`_)
* Add composition_interfaces (`#60 <https://github.com/ros2/rcl_interfaces/issues/60>`_)
* Contributors: Michael Carroll, Shane Loretz

0.6.2 (2019-01-11)
------------------

0.6.1 (2018-12-06)
------------------

0.6.0 (2018-11-16)
------------------

0.5.0 (2018-06-24)
------------------

0.4.0 (2017-12-08)
------------------
