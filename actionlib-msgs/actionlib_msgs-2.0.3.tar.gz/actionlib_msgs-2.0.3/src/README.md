This package is **deprecated** and exists to support bridging ROS 1 action topics.
For ROS 2 actions, see [action_msgs](https://github.com/ros2/rcl_interfaces/tree/master/action_msgs).
