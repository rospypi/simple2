// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTIONLIB_MSGS__MSG__GOAL_ID_HPP_
#define ACTIONLIB_MSGS__MSG__GOAL_ID_HPP_

#include "actionlib_msgs/msg/detail/goal_id__struct.hpp"
#include "actionlib_msgs/msg/detail/goal_id__builder.hpp"
#include "actionlib_msgs/msg/detail/goal_id__traits.hpp"

#endif  // ACTIONLIB_MSGS__MSG__GOAL_ID_HPP_
