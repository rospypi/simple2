// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_HPP_
#define ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_HPP_

#include "actionlib_msgs/msg/detail/goal_status_array__struct.hpp"
#include "actionlib_msgs/msg/detail/goal_status_array__builder.hpp"
#include "actionlib_msgs/msg/detail/goal_status_array__traits.hpp"

#endif  // ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_HPP_
