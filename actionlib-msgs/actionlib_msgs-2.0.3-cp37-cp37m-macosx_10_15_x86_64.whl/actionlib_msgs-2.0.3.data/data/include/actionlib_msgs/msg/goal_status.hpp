// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTIONLIB_MSGS__MSG__GOAL_STATUS_HPP_
#define ACTIONLIB_MSGS__MSG__GOAL_STATUS_HPP_

#include "actionlib_msgs/msg/detail/goal_status__struct.hpp"
#include "actionlib_msgs/msg/detail/goal_status__builder.hpp"
#include "actionlib_msgs/msg/detail/goal_status__traits.hpp"

#endif  // ACTIONLIB_MSGS__MSG__GOAL_STATUS_HPP_
