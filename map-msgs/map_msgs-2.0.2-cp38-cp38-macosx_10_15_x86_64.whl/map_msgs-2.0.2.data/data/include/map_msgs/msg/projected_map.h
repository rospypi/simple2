// generated from rosidl_generator_c/resource/idl.h.em
// with input from map_msgs:msg/ProjectedMap.idl
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__MSG__PROJECTED_MAP_H_
#define MAP_MSGS__MSG__PROJECTED_MAP_H_

#include "map_msgs/msg/detail/projected_map__struct.h"
#include "map_msgs/msg/detail/projected_map__functions.h"
#include "map_msgs/msg/detail/projected_map__type_support.h"

#endif  // MAP_MSGS__MSG__PROJECTED_MAP_H_
