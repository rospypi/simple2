^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package map_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.2 (2019-09-30)
------------------

2.0.1 (2019-04-19)
------------------
* Changed cmake code to use ``add_compile_options`` instead of setting only cxx flags.
* Contributors: Mikael Arguedas

2.0.0 (2018-06-27)
------------------
* Added missing ``---`` separator in services. (`#5 <https://github.com/ros-planning/navigation_msgs/issues/5>`_)
* Changed to use ``std_msgs/Header`` instead of just ``Header``.
* Ported ``map_msgs`` to ROS 2.
* Contributors: Dirk Thomas, Michael Ferguson, Mikael Arguedas, William Woodall

1.13.0 (2015-03-16)
-------------------
* initial release from new repository
* Contributors: Michael Ferguson
