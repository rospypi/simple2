# libyaml_vendor
CMake wrapper downloading and building libyaml

## Quality Declaration files

Quality declaration of external dependency [libyaml](./libyaml_q_declaration.md)
