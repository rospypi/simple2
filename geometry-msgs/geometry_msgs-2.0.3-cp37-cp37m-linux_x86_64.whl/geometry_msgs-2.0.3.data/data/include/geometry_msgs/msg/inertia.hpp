// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__INERTIA_HPP_
#define GEOMETRY_MSGS__MSG__INERTIA_HPP_

#include "geometry_msgs/msg/detail/inertia__struct.hpp"
#include "geometry_msgs/msg/detail/inertia__builder.hpp"
#include "geometry_msgs/msg/detail/inertia__traits.hpp"

#endif  // GEOMETRY_MSGS__MSG__INERTIA_HPP_
