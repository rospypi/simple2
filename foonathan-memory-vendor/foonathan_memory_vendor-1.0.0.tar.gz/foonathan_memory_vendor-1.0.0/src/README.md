# foonathan_memory_vendor
Vendor package for foonathan/memory: https://github.com/foonathan/memory

This package will download, patch, build and install foonathan_memory for its use with Fast-RTPS.
