To launch this test open two different consoles:

In the first one launch: ./HelloWorldExampleSharedMem publisher (or HelloWorldExampleSharedMem.exe publisher on windows).
In the second one: ./HelloWorldExampleSharedMem subscriber (or HelloWorldExampleSharedMem.exe subscriber on windows).

