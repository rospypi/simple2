To launch this test open two different consoles:

In the first one launch: ./RTPSTest_registered writer (or RTPSTest_registered.exe writer on windows).
In the second one: ./RTPSTest_registered reader (or RTPSTest_registered.exe reader on windows).
