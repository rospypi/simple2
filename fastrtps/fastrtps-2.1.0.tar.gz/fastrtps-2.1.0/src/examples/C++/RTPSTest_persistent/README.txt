To launch this test open two different consoles:

In the first one launch: ./RTPSTest_persistent writer (or RTPSTest_persistent.exe writer on windows).
In the second one: ./RTPSTest_persistent reader (or RTPSTest_persistent.exe reader on windows).
