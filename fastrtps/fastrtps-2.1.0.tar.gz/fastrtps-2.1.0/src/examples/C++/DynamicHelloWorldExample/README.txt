To launch this test open two different consoles:

In the first one launch: ./DynamicHelloWorldExample publisher (or DynamicHelloWorldExample.exe publisher on windows).
In the second one: ./DynamicHelloWorldExample subscriber (or DynamicHelloWorldExample.exe subscriber on windows).

