Upgrading from previous versions
================================

If you have used *fastrtpsgen* to generate part of your code, it is always *recommended* to regenerate it.

When upgrading from a version older than 1.7.0, regeneration is **required**.
